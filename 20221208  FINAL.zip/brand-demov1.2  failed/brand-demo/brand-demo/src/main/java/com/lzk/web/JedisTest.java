package com.lzk.web;




import redis.clients.jedis.Jedis;

import java.sql.Time;
import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * 使用Jedis操作Redis
 */
public class JedisTest {



    public static void main(String[] args) {

    }


    public void save(String username){
        //1 获取连接
        Jedis jedis = new Jedis("localhost",6379);

        //2 执行具体的操作
       jedis.sadd("username",username);
      jedis.expire(username,30);


        Set<String> values = jedis.smembers("username");

        for (String value : values) {
            System.out.println(value);
        }
        long l=jedis.scard("username");

        System.out.println("当前时刻有"+l+"位用户登录记录 有效期10分钟");



        //3 关闭连接
        jedis.close();
    }
}