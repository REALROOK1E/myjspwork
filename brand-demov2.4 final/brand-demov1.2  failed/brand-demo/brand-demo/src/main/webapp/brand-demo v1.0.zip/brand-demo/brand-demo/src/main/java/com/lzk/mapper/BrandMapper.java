package com.lzk.mapper;

import com.lzk.pojo.Brand;

import org.apache.ibatis.annotations.*;

import java.util.List;

public interface BrandMapper {
   final int checked =1;
    /**
     * 查询所有
     * @return
     */
    @Select("select * from tb_brand")
    @ResultMap("brandResultMap")
    List<Brand> selectAll();

    @Insert("insert into tb_brand values(null,#{brandName},#{goodsName},#{price},#{adv},#{status})")
    void add(Brand brand);

    /**
     * 根据id查询
     * @param id
     * @return
     */
    @Select("select * from tb_brand where id = #{id}")
    @ResultMap("brandResultMap")
    Brand selectById(int id);

    /**
     * 修改
     * @param brand
     */
    @Update("update tb_brand set brand_name = #{brandName},goods_name = #{goodsName},price = #{price},adv = #{adv},status = #{status} where id = #{id}")
    void update(Brand brand);


    @Select("select * from tb_brand where status = 1")
    @ResultMap("brandResultMap")
    List<Brand> selectBystatus();

}
